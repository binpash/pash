#!/usr/bin/env python3.9
"""
Phase 2: S3 split Reader with Pashlib Inter-Process Communication

Reads one logical split from S3, handling newline boundaries by communicating
with adjacent processes via pashlib FIFOs.

Ports the core algorithm from client/dfs_split_reader.go:
- Lines 96-101: skip_until_newline()
- Lines 62-82: read_until_newline() via pashlib
- Lines 111-146: main orchestration logic

Usage:
    python3.9 s3-shard-reader.py <s3_key> <output_fifo> <byte_range> \
        split=<N> num_shards=<N> job_uid=<UID>

Example:
    python3.9 s3-shard-reader.py "oneliners/inputs/1M.txt" /tmp/fifo21 \
        bytes=0-524287 split=0 num_shards=4 job_uid=test-123
"""

import boto3
import os
import sys
import subprocess
import threading
import time
from botocore.exceptions import ClientError
from io import BytesIO


def _now_ts():
    return f"{time.time():.3f}"


def _get_env_timeout(name, default_seconds):
    raw = os.environ.get(name)
    if not raw:
        return default_seconds
    try:
        value = float(raw)
    except ValueError:
        return default_seconds
    return max(0.0, value)


RENDEZVOUS_PREFIX = os.environ.get("PASH_S3_RENDEZVOUS_PREFIX", "rendezvous")

# Configurable chunk sizes for performance tuning
CHUNK_SIZE = int(os.environ.get("PASH_S3_CHUNK_SIZE", str(8*1024*1024)))  # Default 8MB
FIFO_BUFFER_SIZE = int(os.environ.get("PASH_S3_FIFO_BUFFER", str(8*1024*1024)))  # Default 8MB
RECV_READ_SIZE = int(os.environ.get("PASH_S3_RECV_BUFFER", str(4*1024)))  # Default 4KB


def _rendezvous_key(job_uid, requester_index, target_index, kind):
    return f"{RENDEZVOUS_PREFIX}/{job_uid}/{kind}_{requester_index}_to_{target_index}"


def _s3_marker_exists(s3, bucket, key):
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("404", "NoSuchKey", "NotFound"):
            return False
        raise


def _s3_put_marker(s3, bucket, key, body=b"1"):
    s3.put_object(Bucket=bucket, Key=key, Body=body)


def _s3_delete_marker(s3, bucket, key):
    try:
        s3.delete_object(Bucket=bucket, Key=key)
    except ClientError:
        pass


def _wait_for_marker(s3, bucket, key, timeout_secs, poll_secs, debug=False, log_prefix=""):
    deadline = time.time() + timeout_secs
    while True:
        if _s3_marker_exists(s3, bucket, key):
            if debug and log_prefix:
                print(f"[{_now_ts()}]{log_prefix} Found marker: {key}", file=sys.stderr)
            return True
        if time.time() >= deadline:
            if debug and log_prefix:
                print(f"[{_now_ts()}]{log_prefix} Timeout waiting for marker: {key}", file=sys.stderr)
            return False
        time.sleep(poll_secs)


# Dynamic pashlib path detection
# Works in: Lambda (/opt/pashlib), Local (runtime/pashlib), Custom (PASHLIB_PATH env)
PASHLIB_PATH = os.environ.get('PASHLIB_PATH')
if not PASHLIB_PATH:
    if os.path.exists('/opt/pashlib'):
        PASHLIB_PATH = '/opt/pashlib'  # Lambda environment
    else:
        # Local testing - relative to this script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        PASHLIB_PATH = os.path.join(os.path.dirname(script_dir), 'runtime', 'pashlib')

# Verify pashlib exists
if not os.path.exists(PASHLIB_PATH):
    raise FileNotFoundError(f"Pashlib not found at {PASHLIB_PATH}")


def parse_byte_range(byte_range_str):
    """
    Parse byte range string "bytes=0-524287" into (start, end).
    Returns (start_byte, end_byte) inclusive.
    """
    if not byte_range_str.startswith('bytes='):
        raise ValueError(f"Invalid byte range format: {byte_range_str}")

    range_part = byte_range_str[6:]  # Remove 'bytes='
    start_str, end_str = range_part.split('-')
    return int(start_str), int(end_str)


def parse_keyword_args(args):
    """
    Parse keyword arguments like ['split=0', 'num_shards=4', 'job_uid=test']
    Returns dict {'split': '0', 'num_shards': '4', 'job_uid': 'test'}
    """
    kwargs = {}
    for arg in args:
        if '=' in arg:
            key, value = arg.split('=', 1)
            kwargs[key] = value
    return kwargs


def download_s3_range(bucket, key, start_byte, end_byte):
    """
    Download a specific byte range from S3.
    Returns bytes.
    """
    s3 = boto3.client('s3')

    response = s3.get_object(
        Bucket=bucket,
        Key=key,
        Range=f'bytes={start_byte}-{end_byte}'
    )

    return response['Body'].read()


def stream_s3_to_fifo_handle(fifo_handle, bucket, key, start_byte, end_byte,
                              chunk_size=64*1024*1024, debug=False):
    """
    Download S3 byte range to temp file, then stream to FIFO.

    This decouples S3 download speed from shell processing speed:
    - S3 download completes at full speed (no backpressure, no timeout)
    - Temp file acts as buffer
    - Local disk -> FIFO can wait as long as needed (no S3 timeout risk)

    Requires Lambda /tmp to be >= shard size (increase to 2GB+ in config).
    """
    import shutil

    s3 = boto3.client('s3')
    shard_size = end_byte - start_byte + 1

    # Temp file path unique to this process
    tmp_path = f'/tmp/shard_{os.getpid()}_{start_byte}.tmp'

    if debug:
        print(f"[{_now_ts()}][STREAM] Shard range: bytes={start_byte}-{end_byte} ({shard_size/(1024*1024):.2f} MB)", file=sys.stderr)
        print(f"[{_now_ts()}][STREAM] Strategy: DOWNLOAD_TO_TEMP (decoupled from downstream)", file=sys.stderr)
        print(f"[{_now_ts()}][STREAM] Temp file: {tmp_path}", file=sys.stderr)
        sys.stderr.flush()

    try:
        # PHASE 1: Download S3 range to temp file at full speed
        # No backpressure risk - S3 won't timeout
        download_start = time.time()

        response = s3.get_object(Bucket=bucket, Key=key, Range=f'bytes={start_byte}-{end_byte}')

        bytes_downloaded = 0
        with open(tmp_path, 'wb') as tmp_file:
            for chunk in response['Body'].iter_chunks(chunk_size=chunk_size):
                tmp_file.write(chunk)
                bytes_downloaded += len(chunk)

                if debug and bytes_downloaded % (256*1024*1024) < chunk_size:  # Log every 256MB
                    elapsed = time.time() - download_start
                    speed = bytes_downloaded / (1024*1024) / elapsed if elapsed > 0 else 0
                    pct = 100.0 * bytes_downloaded / shard_size
                    print(f"[{_now_ts()}][STREAM] Downloaded: {bytes_downloaded/(1024*1024):.1f}MB ({pct:.1f}%) at {speed:.1f} MB/s", file=sys.stderr)
                    sys.stderr.flush()

        download_time = time.time() - download_start
        download_speed = shard_size / (1024*1024) / download_time if download_time > 0 else 0

        if debug:
            print(f"[{_now_ts()}][STREAM] Download complete: {shard_size/(1024*1024):.1f}MB in {download_time:.1f}s ({download_speed:.1f} MB/s)", file=sys.stderr)
            sys.stderr.flush()

        # PHASE 2: Stream temp file to FIFO
        # Local disk read is fast, can wait for slow shell commands indefinitely
        stream_start = time.time()

        if debug:
            print(f"[{_now_ts()}][STREAM] Streaming temp file to FIFO...", file=sys.stderr)
            sys.stderr.flush()

        with open(tmp_path, 'rb') as src:
            shutil.copyfileobj(src, fifo_handle, length=64*1024*1024)

        stream_time = time.time() - stream_start

        if debug:
            print(f"[{_now_ts()}][STREAM] Complete: streamed {shard_size/(1024*1024):.1f}MB to FIFO in {stream_time:.1f}s", file=sys.stderr)
            print(f"[{_now_ts()}][STREAM]   Total time: {download_time + stream_time:.1f}s (download: {download_time:.1f}s, stream: {stream_time:.1f}s)", file=sys.stderr)
            sys.stderr.flush()

        return bytes_downloaded

    except Exception as e:
        if debug:
            print(f"[{_now_ts()}][STREAM] ERROR: {e}", file=sys.stderr)
            sys.stderr.flush()
        raise
    finally:
        # Clean up temp file
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass


def upload_to_s3(bucket, key, data, debug=False):
    """
    Upload data to S3.
    Handles errors gracefully - logs but doesn't crash.
    """
    try:
        if debug:
            print(f"[S3_UPLOAD] Uploading to s3://{bucket}/{key} ({len(data)} bytes)", file=sys.stderr)

        s3 = boto3.client('s3')
        s3.put_object(Bucket=bucket, Key=key, Body=data)

        if debug:
            print(f"[S3_UPLOAD] Upload complete", file=sys.stderr)

        return True
    except Exception as e:
        print(f"[S3_UPLOAD] Error uploading to S3: {e}", file=sys.stderr)
        return False


def start_single_server_thread(shard_index, requester_index, job_uid, s3_bucket, s3_key, byte_range_str, debug=False, request_key=None, ready_key=None):
    """
    Background thread that serves requester_index's request for tail bytes.
    Uses pashlib send to transmit bytes until newline.

    Port from Go server logic (server/server.go).
    """
    def server():
        try:
            # UID for communication from requester_index to shard_index
            comm_uid = f"{job_uid}-split-{requester_index}-to-{shard_index}"

            # Create send FIFO (unique per requester)
            send_fifo = f"/tmp/pash_send_{shard_index}_from_{requester_index}_{os.getpid()}"

            # Clean up any existing FIFO
            try:
                os.unlink(send_fifo)
            except FileNotFoundError:
                pass

            os.mkfifo(send_fifo)

            if debug:
                print(f"[{_now_ts()}][SERVER {shard_index}] Created FIFO for requester {requester_index}: {send_fifo}", file=sys.stderr)
                print(f"[{_now_ts()}][SERVER {shard_index}] UID: {comm_uid}", file=sys.stderr)

            # Start pashlib send (blocks until recv side connects)
            pashlib_cmd = [PASHLIB_PATH, f"send*{comm_uid}*0*1*{send_fifo}"]
            if debug:
                print(f"[{_now_ts()}][SERVER {shard_index}] Starting: {' '.join(pashlib_cmd)}", file=sys.stderr)

            proc = subprocess.Popen(pashlib_cmd, stderr=subprocess.PIPE if not debug else None)
            if ready_key:
                s3 = boto3.client('s3')
                _s3_put_marker(s3, s3_bucket, ready_key, b"ready")
                if debug:
                    print(f"[{_now_ts()}][SERVER {shard_index}] Ready marker written for requester {requester_index}", file=sys.stderr)

            # Stream bytes from S3 to send_fifo until newline
            start_byte = parse_byte_range(byte_range_str)[0]

            if debug:
                print(f"[{_now_ts()}][SERVER {shard_index}] Streaming from S3 byte {start_byte} to requester {requester_index}...", file=sys.stderr)

            fifo_fd = os.open(send_fifo, os.O_WRONLY)

            # Use buffered writes with chunk-based streaming for performance
            with os.fdopen(fifo_fd, 'wb', buffering=FIFO_BUFFER_SIZE) as f:
                bytes_written = 0
                for chunk in stream_s3_chunks(s3_bucket, s3_key, start_byte):
                    # Check for newline in chunk
                    try:
                        newline_pos = chunk.index(b'\n')
                        # Write only up to and including the newline
                        f.write(chunk[:newline_pos + 1])
                        bytes_written += newline_pos + 1
                        if debug:
                            print(f"[{_now_ts()}][SERVER {shard_index}] Found newline after {bytes_written} bytes, stopping send to requester {requester_index}", file=sys.stderr)
                        break
                    except ValueError:
                        # No newline in this chunk, write entire chunk
                        f.write(chunk)
                        bytes_written += len(chunk)

            # Cleanup
            proc.wait()
            os.unlink(send_fifo)

            if debug:
                print(f"[{_now_ts()}][SERVER {shard_index}] Complete serving requester {requester_index}", file=sys.stderr)

        except Exception as e:
            print(f"[{_now_ts()}][SERVER {shard_index}] Error serving requester {requester_index}: {e}", file=sys.stderr)
            # Don't raise - let other server threads continue
        finally:
            if request_key or ready_key:
                s3 = boto3.client('s3')
                if request_key:
                    _s3_delete_marker(s3, s3_bucket, request_key)
                if ready_key:
                    _s3_delete_marker(s3, s3_bucket, ready_key)
                if debug:
                    print(f"[{_now_ts()}][SERVER {shard_index}] Cleaned rendezvous markers for requester {requester_index}", file=sys.stderr)

    # Run server in background thread (non-daemon to keep lambda alive while serving)
    thread = threading.Thread(target=server, daemon=False)
    thread.start()

    return thread


def start_request_listener(shard_index, job_uid, s3_bucket, s3_key, byte_range_str, debug=False):
    """
    Start a background listener that launches server threads only when requested.
    """
    def listener():
        s3 = boto3.client('s3')
        served = set()
        poll_secs = max(0.05, _get_env_timeout("PASH_S3_TAIL_DISCOVERY_POLL_SECS", 0.2))

        while True:
            for requester_index in range(shard_index):
                if requester_index in served:
                    continue
                req_key = _rendezvous_key(job_uid, requester_index, shard_index, "req")
                if _s3_marker_exists(s3, s3_bucket, req_key):
                    ready_key = _rendezvous_key(job_uid, requester_index, shard_index, "ready")
                    if debug:
                        print(f"[{_now_ts()}][SERVER {shard_index}] Request detected from {requester_index}", file=sys.stderr)
                    start_single_server_thread(
                        shard_index,
                        requester_index,
                        job_uid,
                        s3_bucket,
                        s3_key,
                        byte_range_str,
                        debug,
                        request_key=req_key,
                        ready_key=ready_key
                    )
                    served.add(requester_index)
            if len(served) == shard_index:
                break
            time.sleep(poll_secs)

    thread = threading.Thread(target=listener, daemon=True)
    thread.start()
    return [thread]


def request_tail_bytes_pashlib(shard_index, num_shards, job_uid, s3_bucket, debug=False):
    """
    Request bytes from subsequent processes until newline using pashlib recv.
    Strict semantics:
      - If the next shard never replies, stop immediately.
      - If it replies but has no newline, continue to the next shard.
    Port from Go lines 62-82 (byte-by-byte reading).
    """
    accumulated_bytes = bytearray()
    s3 = boto3.client('s3')
    discovery_timeout = _get_env_timeout("PASH_S3_TAIL_DISCOVERY_TIMEOUT_SECS", 10.0)
    poll_secs = max(0.05, _get_env_timeout("PASH_S3_TAIL_DISCOVERY_POLL_SECS", 0.2))

    # Loop through subsequent shards: i+1, i+2, ..., n-1
    for target_shard in range(shard_index + 1, num_shards):
        comm_uid = f"{job_uid}-split-{shard_index}-to-{target_shard}"
        req_key = _rendezvous_key(job_uid, shard_index, target_shard, "req")
        ready_key = _rendezvous_key(job_uid, shard_index, target_shard, "ready")
        _s3_put_marker(s3, s3_bucket, req_key, b"req")
        if debug:
            print(f"[{_now_ts()}][CLIENT {shard_index}] Requested tail from shard {target_shard}", file=sys.stderr)

        if not _wait_for_marker(s3, s3_bucket, ready_key, discovery_timeout, poll_secs, debug, f"[CLIENT {shard_index}]"):
            if debug:
                print(f"[{_now_ts()}][CLIENT {shard_index}] No reply from shard {target_shard}; stopping tail search", file=sys.stderr)
            _s3_delete_marker(s3, s3_bucket, req_key)
            break
        recv_fifo = f"/tmp/pash_recv_{shard_index}_to_{target_shard}_{os.getpid()}"

        # Clean up any existing FIFO
        try:
            os.unlink(recv_fifo)
        except FileNotFoundError:
            pass

        os.mkfifo(recv_fifo)

        if debug:
            print(f"[{_now_ts()}][CLIENT {shard_index}] Attempting to read from shard {target_shard}", file=sys.stderr)
            print(f"[{_now_ts()}][CLIENT {shard_index}] Created FIFO: {recv_fifo}", file=sys.stderr)
            print(f"[{_now_ts()}][CLIENT {shard_index}] UID: {comm_uid}", file=sys.stderr)

        try:
            # Start pashlib recv for this hop
            pashlib_cmd = [PASHLIB_PATH, f"recv*{comm_uid}*1*0*{recv_fifo}"]
            if debug:
                print(f"[{_now_ts()}][CLIENT {shard_index}] Starting: {' '.join(pashlib_cmd)}", file=sys.stderr)

            proc = subprocess.Popen(pashlib_cmd, stderr=subprocess.PIPE if not debug else None)

            # Read from this shard until newline OR EOF
            found_newline = False
            bytes_from_this_shard = 0

            if debug:
                print(f"[{_now_ts()}][CLIENT {shard_index}] Reading tail bytes from shard {target_shard}...", file=sys.stderr)

            recv_fd = os.open(recv_fifo, os.O_RDONLY)
            try:
                # Read in buffered chunks for better performance (not byte-by-byte)
                while True:
                    chunk = os.read(recv_fd, RECV_READ_SIZE)
                    if not chunk:  # EOF from this shard
                        if debug:
                            print(f"[{_now_ts()}][CLIENT {shard_index}] EOF from shard {target_shard} after {bytes_from_this_shard} bytes", file=sys.stderr)
                        break

                    # Check for newline in chunk
                    try:
                        newline_pos = chunk.index(b'\n')
                        # Found newline! Add up to and including newline
                        accumulated_bytes.extend(chunk[:newline_pos + 1])
                        bytes_from_this_shard += newline_pos + 1
                        found_newline = True
                        if debug:
                            print(f"[{_now_ts()}][CLIENT {shard_index}] Found newline in shard {target_shard}", file=sys.stderr)
                        break
                    except ValueError:
                        # No newline in this chunk, add entire chunk and continue
                        accumulated_bytes.extend(chunk)
                        bytes_from_this_shard += len(chunk)
            finally:
                os.close(recv_fd)

            proc.wait()

            # If we found newline, we're done - break out of loop
            if found_newline:
                if debug:
                    print(f"[{_now_ts()}][CLIENT {shard_index}] Total received: {len(accumulated_bytes)} bytes across {target_shard - shard_index} hop(s)", file=sys.stderr)
                break

            # Otherwise, continue to next shard
            if debug:
                print(f"[{_now_ts()}][CLIENT {shard_index}] No newline in shard {target_shard}, continuing to next shard...", file=sys.stderr)

        finally:
            # Cleanup FIFO for this hop
            try:
                os.unlink(recv_fifo)
            except FileNotFoundError:
                pass
            _s3_delete_marker(s3, s3_bucket, req_key)
            _s3_delete_marker(s3, s3_bucket, ready_key)

    # After loop: either found newline OR exhausted all shards
    if not accumulated_bytes.endswith(b'\n') and debug:
        print(f"[{_now_ts()}][CLIENT {shard_index}] WARNING: No newline found in any subsequent shard", file=sys.stderr)

    return bytes(accumulated_bytes)


def main():
    try:
        # Parse command line arguments
        if len(sys.argv) < 4:
            print("Usage: python3.9 s3-shard-reader.py <s3_key> <output_fifo> <byte_range> split=<N> num_shards=<N> job_uid=<UID>", file=sys.stderr)
            print("Example: python3.9 s3-shard-reader.py 'oneliners/inputs/1M.txt' /tmp/fifo21 bytes=0-524287 split=0 num_shards=4 job_uid=test-123", file=sys.stderr)
            sys.exit(1)

        # Positional arguments
        s3_key = sys.argv[1]
        output_fifo = sys.argv[2]
        byte_range_str = sys.argv[3]

        # Parse keyword arguments
        kwargs = parse_keyword_args(sys.argv[4:])
        shard_index = int(kwargs.get('shard', 0))
        num_shards = int(kwargs.get('num_shards', 1))
        job_uid = kwargs.get('job_uid', 'default')
        debug = kwargs.get('debug', 'false').lower() == 'true'

        # Get bucket from environment
        s3_bucket = os.environ.get('AWS_BUCKET')
        if not s3_bucket:
            print("Error: AWS_BUCKET environment variable not set", file=sys.stderr)
            sys.stderr.flush()
            sys.exit(1)

        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] Starting", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] S3: {s3_bucket}/{s3_key}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] Range: {byte_range_str}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] split: {shard_index}/{num_shards}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] UID: {job_uid}", file=sys.stderr)
            sys.stderr.flush()

        # Smart boundary mode: boundaries are line-aligned, no inter-lambda communication needed
        if debug and shard_index > 0:
            print(f"[{_now_ts()}][MAIN {shard_index}] Smart boundary mode: Boundary is line-aligned, skipping request listener", file=sys.stderr)
            sys.stderr.flush()

        # 2. Parse byte range
        start_byte, end_byte = parse_byte_range(byte_range_str)

        # 3. Open FIFO and stream S3 directly to it
        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] Opening FIFO: {output_fifo}", file=sys.stderr)
            sys.stderr.flush()

        # Open FIFO for writing (blocks until downstream reader connects)
        with open(output_fifo, 'wb', buffering=0) as fifo:
            if debug:
                print(f"[{_now_ts()}][MAIN {shard_index}] FIFO connected, streaming S3 range {start_byte}-{end_byte}", file=sys.stderr)
                sys.stderr.flush()

            # Stream S3 data to FIFO
            bytes_streamed = stream_s3_to_fifo_handle(
                fifo, s3_bucket, s3_key, start_byte, end_byte,
                chunk_size=256*1024*1024,  # 256MB chunks for streaming
                debug=debug
            )

            if debug:
                print(f"[{_now_ts()}][MAIN {shard_index}] Streamed {bytes_streamed} bytes from S3", file=sys.stderr)
                sys.stderr.flush()

            # Smart boundary mode: boundary already line-aligned, no tail bytes needed
            if debug and shard_index < num_shards - 1 and bytes_streamed > 0:
                print(f"[{_now_ts()}][MAIN {shard_index}] Smart boundary mode: Boundary is line-aligned, skipping tail byte request", file=sys.stderr)
                sys.stderr.flush()

        # Note: S3 upload skipped in streaming mode (data already consumed by downstream)
        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] FIFO closed, data transmitted to downstream", file=sys.stderr)
            sys.stderr.flush()

        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] Complete", file=sys.stderr)
            sys.stderr.flush()

    except Exception as e:
        print(f"[{_now_ts()}][ERROR] Fatal exception in main: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.stderr.flush()
        sys.exit(1)


if __name__ == '__main__':
    main()
