#!/usr/bin/env python3.9
"""
S3 Shard Reader with TRUE Streaming and Lambda-to-Lambda Communication

Key difference from s3-shard-reader.py (smart boundaries mode):
- Streams data to FIFO immediately as it downloads
- Downstream shell commands start processing right away
- Only sequential dependency is for the LAST LINE (tail byte request)
- All other lines are processed in parallel across all lambdas

Architecture:
  Lambda 0: [====== stream all lines ======][wait for Lambda 1 to request tail]
  Lambda 1: [====== stream all lines ======][request tail from 0][wait for 2]
  Lambda 2: [====== stream all lines ======][request tail from 1][wait for 3]
  ...

Usage:
    python3.9 s3-shard-reader-streaming.py <s3_key> <output_fifo> <byte_range> \
        shard=<N> num_shards=<N> job_uid=<UID>
"""

import boto3
import os
import sys
import subprocess
import threading
import time
import queue
from botocore.exceptions import ClientError
from io import BytesIO


def _now_ts():
    return f"{time.time():.3f}"


def _get_env_timeout(name, default_seconds):
    raw = os.environ.get(name)
    if not raw:
        return default_seconds
    try:
        value = float(raw)
    except ValueError:
        return default_seconds
    return max(0.0, value)


RENDEZVOUS_PREFIX = os.environ.get("PASH_S3_RENDEZVOUS_PREFIX", "rendezvous")

# Configurable chunk sizes
CHUNK_SIZE = int(os.environ.get("PASH_S3_CHUNK_SIZE", str(8*1024*1024)))  # 8MB default
RECV_READ_SIZE = int(os.environ.get("PASH_S3_RECV_BUFFER", str(64*1024)))  # 64KB default


def _rendezvous_key(job_uid, requester_index, target_index, kind):
    return f"{RENDEZVOUS_PREFIX}/{job_uid}/{kind}_{requester_index}_to_{target_index}"


def _s3_marker_exists(s3, bucket, key):
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("404", "NoSuchKey", "NotFound"):
            return False
        raise


def _s3_put_marker(s3, bucket, key, body=b"1"):
    s3.put_object(Bucket=bucket, Key=key, Body=body)


def _s3_delete_marker(s3, bucket, key):
    try:
        s3.delete_object(Bucket=bucket, Key=key)
    except ClientError:
        pass


def _wait_for_marker(s3, bucket, key, timeout_secs, poll_secs, debug=False, log_prefix=""):
    deadline = time.time() + timeout_secs
    while True:
        if _s3_marker_exists(s3, bucket, key):
            if debug and log_prefix:
                print(f"[{_now_ts()}]{log_prefix} Found marker: {key}", file=sys.stderr)
            return True
        if time.time() >= deadline:
            if debug and log_prefix:
                print(f"[{_now_ts()}]{log_prefix} Timeout waiting for marker: {key}", file=sys.stderr)
            return False
        time.sleep(poll_secs)


# Dynamic pashlib path detection
PASHLIB_PATH = os.environ.get('PASHLIB_PATH')
if not PASHLIB_PATH:
    if os.path.exists('/opt/pashlib'):
        PASHLIB_PATH = '/opt/pashlib'
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        PASHLIB_PATH = os.path.join(os.path.dirname(script_dir), 'runtime', 'pashlib')

if not os.path.exists(PASHLIB_PATH):
    raise FileNotFoundError(f"Pashlib not found at {PASHLIB_PATH}")


def parse_byte_range(byte_range_str):
    if not byte_range_str.startswith('bytes='):
        raise ValueError(f"Invalid byte range format: {byte_range_str}")
    range_part = byte_range_str[6:]
    start_str, end_str = range_part.split('-')
    return int(start_str), int(end_str)


def parse_keyword_args(args):
    kwargs = {}
    for arg in args:
        if '=' in arg:
            key, value = arg.split('=', 1)
            kwargs[key] = value
    return kwargs


class StreamingS3ToFifo:
    """
    Streams S3 data to FIFO while tracking the last line for tail byte serving.

    Key features:
    1. Writes to FIFO immediately as data arrives (TRUE STREAMING)
    2. Keeps track of partial last line (for serving to next lambda)
    3. Skips first line if needed (for shard > 0)
    """

    def __init__(self, bucket, key, start_byte, end_byte, fifo_handle,
                 skip_first_line=False, debug=False):
        self.bucket = bucket
        self.key = key
        self.start_byte = start_byte
        self.end_byte = end_byte
        self.fifo_handle = fifo_handle
        self.skip_first_line = skip_first_line
        self.debug = debug

        self.s3 = boto3.client('s3')
        self.bytes_written = 0
        self.last_line_buffer = bytearray()  # Track partial last line
        self.first_line_skipped = not skip_first_line  # True if we don't need to skip
        self.streaming_complete = threading.Event()
        self.error = None

    def stream(self):
        """
        Stream S3 data to FIFO.
        Returns number of bytes written.
        """
        try:
            if self.debug:
                print(f"[{_now_ts()}][STREAM] Starting S3 download: bytes={self.start_byte}-{self.end_byte}", file=sys.stderr)
                sys.stderr.flush()

            response = self.s3.get_object(
                Bucket=self.bucket,
                Key=self.key,
                Range=f'bytes={self.start_byte}-{self.end_byte}'
            )

            for chunk in response['Body'].iter_chunks(chunk_size=CHUNK_SIZE):
                self._process_chunk(chunk)

            # Flush any remaining data in last_line_buffer
            # (This is the partial last line that doesn't end with newline)
            # We write it to FIFO but keep it in buffer for tail byte serving

            if self.debug:
                print(f"[{_now_ts()}][STREAM] Complete: wrote {self.bytes_written} bytes to FIFO", file=sys.stderr)
                if self.last_line_buffer:
                    print(f"[{_now_ts()}][STREAM] Last line buffer: {len(self.last_line_buffer)} bytes (for tail serving)", file=sys.stderr)
                sys.stderr.flush()

            return self.bytes_written

        except Exception as e:
            self.error = e
            if self.debug:
                print(f"[{_now_ts()}][STREAM] ERROR: {e}", file=sys.stderr)
                sys.stderr.flush()
            raise
        finally:
            self.streaming_complete.set()

    def _process_chunk(self, chunk):
        """Process a chunk of data, handling first line skip and tracking last line."""

        # Skip first line if needed (for shard > 0)
        if not self.first_line_skipped:
            try:
                newline_pos = chunk.index(b'\n')
                chunk = chunk[newline_pos + 1:]  # Skip up to and including first newline
                self.first_line_skipped = True
                if self.debug:
                    print(f"[{_now_ts()}][STREAM] Skipped first {newline_pos + 1} bytes (first line)", file=sys.stderr)
            except ValueError:
                # No newline in chunk - entire chunk is part of first line, skip it all
                return

        if not chunk:
            return

        # Find last newline in chunk to update last_line_buffer
        try:
            last_newline = chunk.rindex(b'\n')

            # Write everything up to and including last newline
            data_to_write = self.last_line_buffer + chunk[:last_newline + 1]
            self.fifo_handle.write(bytes(data_to_write))
            self.fifo_handle.flush()
            self.bytes_written += len(data_to_write)

            # Keep partial line after last newline in buffer
            self.last_line_buffer = bytearray(chunk[last_newline + 1:])

        except ValueError:
            # No newline in chunk - append to last_line_buffer
            # DON'T write to FIFO yet - this might be part of a line that continues
            self.last_line_buffer.extend(chunk)

    def get_last_line_bytes(self):
        """Get the partial last line (for serving to next lambda)."""
        return bytes(self.last_line_buffer)


def start_tail_server_thread(shard_index, job_uid, s3_bucket, streamer, debug=False):
    """
    Background thread that serves tail bytes to requesting lambdas.

    IMPORTANT: This runs IN PARALLEL with streaming, not after.
    The server sends data from the START of this shard (for the previous lambda's tail).
    """

    def server():
        s3 = boto3.client('s3')
        poll_secs = max(0.05, _get_env_timeout("PASH_S3_TAIL_DISCOVERY_POLL_SECS", 0.2))
        served = set()

        while True:
            for requester_index in range(shard_index):
                if requester_index in served:
                    continue

                req_key = _rendezvous_key(job_uid, requester_index, shard_index, "req")
                if _s3_marker_exists(s3, s3_bucket, req_key):
                    if debug:
                        print(f"[{_now_ts()}][SERVER {shard_index}] Request from {requester_index}", file=sys.stderr)

                    # Serve this requester
                    _serve_tail_bytes(shard_index, requester_index, job_uid, s3_bucket,
                                     streamer, debug, req_key)
                    served.add(requester_index)

            if len(served) == shard_index:
                break
            time.sleep(poll_secs)

    thread = threading.Thread(target=server, daemon=True)
    thread.start()
    return thread


def _serve_tail_bytes(shard_index, requester_index, job_uid, s3_bucket, streamer, debug, req_key):
    """Serve tail bytes from START of this shard to requester."""
    try:
        comm_uid = f"{job_uid}-split-{requester_index}-to-{shard_index}"
        send_fifo = f"/tmp/pash_send_{shard_index}_from_{requester_index}_{os.getpid()}"
        ready_key = _rendezvous_key(job_uid, requester_index, shard_index, "ready")

        try:
            os.unlink(send_fifo)
        except FileNotFoundError:
            pass
        os.mkfifo(send_fifo)

        # Start pashlib send
        pashlib_cmd = [PASHLIB_PATH, f"send*{comm_uid}*0*1*{send_fifo}"]
        proc = subprocess.Popen(pashlib_cmd, stderr=subprocess.PIPE if not debug else None)

        # Signal ready
        s3 = boto3.client('s3')
        _s3_put_marker(s3, s3_bucket, ready_key, b"ready")

        if debug:
            print(f"[{_now_ts()}][SERVER {shard_index}] Ready for {requester_index}, streaming from S3", file=sys.stderr)

        # Stream bytes from START of this shard until newline
        fifo_fd = os.open(send_fifo, os.O_WRONLY)
        with os.fdopen(fifo_fd, 'wb', buffering=0) as f:
            bytes_sent = 0

            # Read from S3 starting at this shard's start_byte
            response = boto3.client('s3').get_object(
                Bucket=s3_bucket,
                Key=streamer.key,
                Range=f'bytes={streamer.start_byte}-{streamer.end_byte}'
            )

            for chunk in response['Body'].iter_chunks(chunk_size=CHUNK_SIZE):
                try:
                    newline_pos = chunk.index(b'\n')
                    # Found newline - send up to and including it, then stop
                    f.write(chunk[:newline_pos + 1])
                    bytes_sent += newline_pos + 1
                    if debug:
                        print(f"[{_now_ts()}][SERVER {shard_index}] Sent {bytes_sent} bytes to {requester_index} (found newline)", file=sys.stderr)
                    break
                except ValueError:
                    # No newline - send entire chunk
                    f.write(chunk)
                    bytes_sent += len(chunk)

        proc.wait()
        os.unlink(send_fifo)

        if debug:
            print(f"[{_now_ts()}][SERVER {shard_index}] Complete serving {requester_index}", file=sys.stderr)

    except Exception as e:
        print(f"[{_now_ts()}][SERVER {shard_index}] Error serving {requester_index}: {e}", file=sys.stderr)
    finally:
        _s3_delete_marker(s3, s3_bucket, req_key)
        _s3_delete_marker(s3, s3_bucket, ready_key)


def request_tail_bytes(shard_index, num_shards, job_uid, s3_bucket, debug=False):
    """
    Request tail bytes from next shard(s) to complete the last line.

    This is called AFTER streaming is complete, only for the last line.
    """
    accumulated_bytes = bytearray()
    s3 = boto3.client('s3')
    discovery_timeout = _get_env_timeout("PASH_S3_TAIL_DISCOVERY_TIMEOUT_SECS", 30.0)
    poll_secs = max(0.05, _get_env_timeout("PASH_S3_TAIL_DISCOVERY_POLL_SECS", 0.2))

    for target_shard in range(shard_index + 1, num_shards):
        comm_uid = f"{job_uid}-split-{shard_index}-to-{target_shard}"
        req_key = _rendezvous_key(job_uid, shard_index, target_shard, "req")
        ready_key = _rendezvous_key(job_uid, shard_index, target_shard, "ready")

        _s3_put_marker(s3, s3_bucket, req_key, b"req")
        if debug:
            print(f"[{_now_ts()}][CLIENT {shard_index}] Requested tail from shard {target_shard}", file=sys.stderr)

        if not _wait_for_marker(s3, s3_bucket, ready_key, discovery_timeout, poll_secs, debug, f"[CLIENT {shard_index}]"):
            if debug:
                print(f"[{_now_ts()}][CLIENT {shard_index}] No reply from {target_shard}, stopping", file=sys.stderr)
            _s3_delete_marker(s3, s3_bucket, req_key)
            break

        recv_fifo = f"/tmp/pash_recv_{shard_index}_to_{target_shard}_{os.getpid()}"
        try:
            os.unlink(recv_fifo)
        except FileNotFoundError:
            pass
        os.mkfifo(recv_fifo)

        try:
            pashlib_cmd = [PASHLIB_PATH, f"recv*{comm_uid}*1*0*{recv_fifo}"]
            proc = subprocess.Popen(pashlib_cmd, stderr=subprocess.PIPE if not debug else None)

            found_newline = False
            recv_fd = os.open(recv_fifo, os.O_RDONLY)
            try:
                while True:
                    chunk = os.read(recv_fd, RECV_READ_SIZE)
                    if not chunk:
                        break

                    try:
                        newline_pos = chunk.index(b'\n')
                        accumulated_bytes.extend(chunk[:newline_pos + 1])
                        found_newline = True
                        break
                    except ValueError:
                        accumulated_bytes.extend(chunk)
            finally:
                os.close(recv_fd)

            proc.wait()

            if found_newline:
                if debug:
                    print(f"[{_now_ts()}][CLIENT {shard_index}] Got {len(accumulated_bytes)} tail bytes", file=sys.stderr)
                break

        finally:
            try:
                os.unlink(recv_fifo)
            except FileNotFoundError:
                pass
            _s3_delete_marker(s3, s3_bucket, req_key)
            _s3_delete_marker(s3, s3_bucket, ready_key)

    return bytes(accumulated_bytes)


def main():
    try:
        if len(sys.argv) < 4:
            print("Usage: python3.9 s3-shard-reader-streaming.py <s3_key> <output_fifo> <byte_range> shard=<N> num_shards=<N> job_uid=<UID>", file=sys.stderr)
            sys.exit(1)

        s3_key = sys.argv[1]
        output_fifo = sys.argv[2]
        byte_range_str = sys.argv[3]

        kwargs = parse_keyword_args(sys.argv[4:])
        shard_index = int(kwargs.get('shard', 0))
        num_shards = int(kwargs.get('num_shards', 1))
        job_uid = kwargs.get('job_uid', 'default')
        skip_first_line = kwargs.get('skip_first_line', 'true').lower() == 'true'
        debug = kwargs.get('debug', 'false').lower() == 'true'

        s3_bucket = os.environ.get('AWS_BUCKET')
        if not s3_bucket:
            print("Error: AWS_BUCKET environment variable not set", file=sys.stderr)
            sys.exit(1)

        start_byte, end_byte = parse_byte_range(byte_range_str)

        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] Starting (TRUE STREAMING MODE)", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] S3: {s3_bucket}/{s3_key}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] Range: {byte_range_str}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] shard: {shard_index}/{num_shards}", file=sys.stderr)
            print(f"[{_now_ts()}][MAIN {shard_index}] skip_first_line: {skip_first_line and shard_index > 0}", file=sys.stderr)
            sys.stderr.flush()

        # Open FIFO FIRST (enables downstream to start consuming immediately)
        with open(output_fifo, 'wb', buffering=0) as fifo:
            if debug:
                print(f"[{_now_ts()}][MAIN {shard_index}] FIFO connected, starting parallel operations", file=sys.stderr)
                sys.stderr.flush()

            # Create streamer
            streamer = StreamingS3ToFifo(
                bucket=s3_bucket,
                key=s3_key,
                start_byte=start_byte,
                end_byte=end_byte,
                fifo_handle=fifo,
                skip_first_line=(skip_first_line and shard_index > 0),
                debug=debug
            )

            # Start tail server in PARALLEL (for previous lambdas requesting our data)
            server_thread = None
            if shard_index > 0:
                if debug:
                    print(f"[{_now_ts()}][MAIN {shard_index}] Starting tail server for {shard_index} potential requesters", file=sys.stderr)
                server_thread = start_tail_server_thread(shard_index, job_uid, s3_bucket, streamer, debug)

            # Stream S3 data to FIFO (TRUE STREAMING - writes immediately)
            bytes_streamed = streamer.stream()

            if debug:
                print(f"[{_now_ts()}][MAIN {shard_index}] S3 streaming complete: {bytes_streamed} bytes", file=sys.stderr)
                sys.stderr.flush()

            # NOW request tail bytes from NEXT shard (only for last line!)
            if shard_index < num_shards - 1:
                if debug:
                    print(f"[{_now_ts()}][MAIN {shard_index}] Requesting tail bytes for last line", file=sys.stderr)

                tail_bytes = request_tail_bytes(shard_index, num_shards, job_uid, s3_bucket, debug)

                if tail_bytes:
                    # Write the last partial line + tail bytes
                    last_line = streamer.get_last_line_bytes()
                    fifo.write(last_line + tail_bytes)
                    fifo.flush()

                    if debug:
                        print(f"[{_now_ts()}][MAIN {shard_index}] Wrote last line: {len(last_line)} + {len(tail_bytes)} tail bytes", file=sys.stderr)
                elif streamer.get_last_line_bytes():
                    # No tail bytes but we have a partial last line - write it anyway
                    fifo.write(streamer.get_last_line_bytes())
                    fifo.flush()

        if debug:
            print(f"[{_now_ts()}][MAIN {shard_index}] Complete", file=sys.stderr)
            sys.stderr.flush()

    except Exception as e:
        print(f"[{_now_ts()}][ERROR] Fatal exception: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
